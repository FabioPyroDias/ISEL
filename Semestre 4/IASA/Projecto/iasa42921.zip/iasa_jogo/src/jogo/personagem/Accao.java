/**
 * Este enumerado representará o que o agente inteligente fará, com base na sua percepção
 * e processamento da mesma.
 * O resultado da função de saída.
 */
public enum Accao {
    PROCURAR,
    APROXIMAR,
    OBSERVAR,
    FOTOGRAFAR
}