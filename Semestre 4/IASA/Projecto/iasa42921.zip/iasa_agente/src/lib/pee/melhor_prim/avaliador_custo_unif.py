from fronteira import avaliador
from mec_proc import no

class AvaliadorCustoUnif(Avaliador):

    def prioridade(self, no):
        pass
