class Solucao:

    def __init__(self, no_final):
        self.__no_final = no_final
    
    def remover(self):
        pass

    def __iter__(self):
        pass

    def __getItem__(self, index):
        pass