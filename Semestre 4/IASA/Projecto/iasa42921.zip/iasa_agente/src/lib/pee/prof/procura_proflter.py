from procura_prof_lim import ProcuraProfLim

class ProcuraProflter(ProcuraProfLim):

    def procurar(self, problema, inc_prof=1, limite_prof=100):
        pass