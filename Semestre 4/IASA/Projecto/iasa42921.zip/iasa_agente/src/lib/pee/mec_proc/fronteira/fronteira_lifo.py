from fronteira import Fronteira

class FronteiraFIFO(Fronteira):

    def inserir(self, no):
        pass