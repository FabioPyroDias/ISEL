from ..mec_proc.mecanismo_procura import MecanismoProcura

class ProcuraProfundidade(MecanismoProcura):

    def __init__(self):
        pass

    def _memorizar(self, no):
        return super()._memorizar(no)