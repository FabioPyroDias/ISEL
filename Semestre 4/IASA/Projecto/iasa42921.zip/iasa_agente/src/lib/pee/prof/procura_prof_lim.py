from procura_profundidade import ProcuraProfundidade
from mec_proc import No

'''
Dado que a aula foi cancelada e não fui informado que o projecto não fora adiado.
Vai assim
'''
class ProcuraProfLim(ProcuraProfundidade):
    
    prof_max = 0
    
    def __init__(self, prof_max=100):
        self.prof_max = prof_max
    
    def _expandir(self, problema, no):
        if no.profundidade > self.prof_max:
            super.expandir(problema, no)

    def _memorizar(self, no):
        if self._ciclo(no):
            super()._memorizar(no)

    def _ciclo(self, no):
        pass