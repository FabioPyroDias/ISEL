from procura_grafo import ProcuraGrafo

class ProcuraLargura(ProcuraGrafo):

    def __init__(self, fronteira):
        pass