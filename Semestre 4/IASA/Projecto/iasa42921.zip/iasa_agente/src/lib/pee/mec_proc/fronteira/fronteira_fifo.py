from fronteira import Fronteira

class FronteiraLIFO(Fronteira):

    def inserir(self, no):
        pass