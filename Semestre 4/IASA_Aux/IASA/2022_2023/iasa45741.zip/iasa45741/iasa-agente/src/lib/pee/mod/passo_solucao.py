class PassoSolucao():
    def __init__(self, estado, operador):
        self.estado = estado
        self.operador = operador