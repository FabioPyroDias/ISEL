package jogo.personagem;

public enum Accao {
    PROCURAR,
    APROXIMAR,
    OBSERVAR,
    FOTOGRAFAR
}
