public interface ProtocoloTeste {
	
	public String REGISTAR = "REGISTAR ";
	public String JOGADA_EFECTUADA = "JOGADA ";
	
	//Prefixos recebidos pelo Cliente
	public String LISTA_CLIENTES = "LISTA_CLIENTES ";
}