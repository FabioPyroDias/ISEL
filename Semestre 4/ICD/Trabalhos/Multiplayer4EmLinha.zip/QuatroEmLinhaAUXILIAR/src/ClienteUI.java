import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class ClienteUI extends JFrame {

	private JPanel contentPane;

	private Cliente cliente;
	private JTextField textFieldNome;
	private JTextField textFieldSimbolo;
	private JPanel panelPlayers;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {

		Cliente cliente = new Cliente("localhost", 50000, args);
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClienteUI frame = new ClienteUI(cliente);
					frame.setVisible(true);
					cliente.setClienteUI(frame); //Adicionar a refer�ncia do UI
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ClienteUI(Cliente cliente) {
		
		this.cliente = cliente;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("434x261");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(0, 0, 434, 200);
		contentPane.add(lblNewLabel);
		
		JButton buttonCol0 = new JButton("New button");
		buttonCol0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cliente.enviarJogada("0");
				System.out.println(cliente.getNome() + ": Enviei Jogada - Col 0");
			}
		});
		buttonCol0.setBounds(0, 238, 54, 23);
		contentPane.add(buttonCol0);
		
		JButton buttonCol1 = new JButton("New button");
		buttonCol1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cliente.enviarJogada("1");
				System.out.println(cliente.getNome() + ": Enviei Jogada - Col 1");
			}
		});
		buttonCol1.setBounds(54, 238, 54, 23);
		contentPane.add(buttonCol1);
		
		JButton buttonCol2 = new JButton("New button");
		buttonCol2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cliente.enviarJogada("2");
				System.out.println(cliente.getNome() + ": Enviei Jogada - Col 2");
			}
		});
		buttonCol2.setBounds(108, 238, 54, 23);
		contentPane.add(buttonCol2);
		
		textFieldNome = new JTextField();
		textFieldNome.setBounds(260, 239, 120, 20);
		contentPane.add(textFieldNome);
		textFieldNome.setColumns(10);
		
		JButton buttonDefinirNome = new JButton("New button");
		buttonDefinirNome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cliente.RegistarNaListaDeClientes(textFieldNome.getText());
			}
		});
		buttonDefinirNome.setBounds(380, 238, 54, 23);
		contentPane.add(buttonDefinirNome);
		
		textFieldSimbolo = new JTextField();
		textFieldSimbolo.setColumns(10);
		textFieldSimbolo.setBounds(166, 239, 84, 20);
		contentPane.add(textFieldSimbolo);
		
		panelPlayers = new JPanel();
		panelPlayers.setBackground(Color.MAGENTA);
		panelPlayers.setBounds(226, 11, 208, 189);
		contentPane.add(panelPlayers);
		panelPlayers.setLayout(null);
	}
	
	public void adicionarClienteALista(RepresentacaoCliente clienteAAdicionar)
	{
		System.out.println("CLIENTE UI -> Fui chamado");
		panelPlayers.add(clienteAAdicionar);
		contentPane.repaint();
		System.out.println("CLIENTE UI -> Acabei");
	}
}
