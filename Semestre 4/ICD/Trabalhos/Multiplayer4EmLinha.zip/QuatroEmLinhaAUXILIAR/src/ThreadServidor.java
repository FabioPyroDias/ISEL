import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

class ThreadServidor extends Thread implements ProtocoloTeste{

	private RegistoCliente eu;
	private ArrayList<RegistoCliente> listaClientes;

	private Socket connection;
    private BufferedReader socketReader;
    private PrintWriter socketWriter;

    
    public ThreadServidor(Socket connection, ArrayList<RegistoCliente> listaClientes) {
        this.connection = connection;
        this.listaClientes = listaClientes;
    }


    public void run() {

        try {
            socketReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            socketWriter = new PrintWriter(connection.getOutputStream(), true);
            
            for(;;)
            {
            	String inputLine = socketReader.readLine();
            	AnaliseMessage(inputLine);           	
            }
            
        }
        catch (IOException e) {
            System.err.println("erro na liga�ao " + connection + ": " + e.getMessage());
        }
        finally {
            // garantir que o socket � fechado
            try {
                if (socketReader != null) socketReader.close();  
                if (socketWriter != null) socketWriter.close();

                if (connection != null) connection.close();                    
            } catch (IOException e) { } 
        }
        
    } // end run

    
    private void AnaliseMessage(String message)
    {
    	String[] parameters = message.split(" ");
    	switch(parameters[0] + " ")
    	{
    		case REGISTAR:
    			registarCliente(parameters[1]);
    			enviarListaClientes();
    			break;
    			
    		case JOGADA_EFECTUADA:
    			executarJogada(parameters[3], parameters[4]);
    			
    			//Foi o jogador associado que jogou
    			if(eu.getNome().equals(parameters[1]))
				{
    				//Enviar a mesma mensagem ao jogador que n�o jogou.
    				//enviarMensagem(parameters[1], JOGADA_EFECTUADA + parameters[0] + parameters[1] + parameters[2] + parameters[3] + parameters[4]);
    				
    				//Enviar apenas tabuleiro atualizado ao jogador associado.
    				//enviarMensagem(eu.getNome(), ATUALIZAR_ESTADO_JOGO + );
				}
    			else //N�o foi o jogador associado que jogou
    			{
    				//Enviar tabuleiro atualizado ao jogador associado e desbloqueio dos bot�es respectivos
    				//enviarMensagem(eu.getNome(), ATUALIZAR_ESTADO_JOGO + );
    			}
    			
    			break;
    	}
    	
    }
    
    private void registarCliente(String nome)
    {
    	eu = new RegistoCliente();
        eu.setNome(nome);
        eu.setSocket(connection);
        eu.setSocketReader(socketReader);
        eu.setSocketWriter(socketWriter);
        
        listaClientes.add(eu);
    }
    
    private void enviarListaClientes()
    {
    	int numeroClientes = listaClientes.size();
    	String mensagemLista = LISTA_CLIENTES + numeroClientes + " ";
    	
    	for(int clienteIndex = 0; clienteIndex < numeroClientes; clienteIndex++)
    	{
    		RegistoCliente cliente = listaClientes.get(clienteIndex);
    		mensagemLista += cliente.getNome() + " ";
    		mensagemLista += cliente.getJogosJogados() + " ";
    		mensagemLista += cliente.getJogosGanhos() + " ";
    	}
    	
    	eu.getSocketWriter().println(mensagemLista);
    }

    private void executarJogada(String coluna, String simbolo)
    {
    	//Inserir pe�a no Tabuleiro.
    	
    }
    
    private void actualizarTurno(String jogadorQueEfectuouJogada)
    {
    	
    }
    
    /*//TODO NOTAS:
     * -> Atualiza��o da Lista de Clientes
     * Sempre que um jogador se registar, a ThreadServidor vai ter de atualizar a 
     * representa��o visual da lista de clientes dos outros Clientes, o lobby.
     * Para tal, vai ter de existir um m�todo que volta a enviar a lista atualizada
     * de clientes e, na ThreadCliente, quando receber essa mensagem, informa a classe
     * base Cliente que, por sua vez, pega nessa mensagem e atualiza a representa��o
     * visual com base nessa mensagem.
     * Assim, acredito que a classe ClienteUI tamb�m vai ter de ser passada como
     * parametro para a classe Cliente.
     * 
     *
     */
}