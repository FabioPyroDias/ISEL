import java.awt.Color;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class Cliente implements ProtocoloTeste {

	private String host;
	private int port;
	
	private String nomeCliente;
	private Socket socket;
	private BufferedReader socketReader;
	private PrintWriter socketWriter;
	
	private ArrayList<RegistoCliente> clientes;
	private String simbolo;
	
	private ClienteUI clienteUI;
	
	public Cliente(String defaultHost, int defaultPort, String[] args)
	{
		this.host = defaultHost;
		this.port = defaultPort;
		
		if (args.length > 0) {
            host = args[0];
        }
        
        if (args.length > 1) {
            try {
                int portInArgument = Integer.parseInt(args[1]);
                if (portInArgument >= 1 || portInArgument <= 65535) port = portInArgument;
            }
            catch (NumberFormatException e) {
                System.err.println("Erro no porto indicado");
            }
        }
		
		try {
            socket = new Socket(host, port);

            // Mostrar os parametros da liga��o
            System.out.println("Liga��o: " + socket);

            // Stream para escrita no socket
            socketWriter = new PrintWriter(socket.getOutputStream(), true); 

            // Stream para leitura do socket
            socketReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            ThreadCliente thread = new ThreadCliente(this, socketReader);
            thread.start();
            
            
            System.out.println("Conex�o Estabelecida");
		}
		catch (IOException e) {
            System.err.println("Erro na liga��o " + e.getMessage());   
        }
	}	

	public void RegistarNaListaDeClientes(String nomeCliente)
	{
		definirNome(nomeCliente);
		socketWriter.println(REGISTAR + nomeCliente);
	}
	
	public void definirNome(String nome)
	{
		this.nomeCliente = nome;
	}
	
	public void definirSimbolo(String simbolo)
	{
		this.simbolo = simbolo;
	}
	
	public String getNome()
	{
		return nomeCliente;
	}
	
	public void enviarJogada(String coluna)
	{
		String nome = "";
		
		for(RegistoCliente cliente : clientes)
		{
			if(!cliente.getNome().equals(nomeCliente))
			{
				nome = cliente.getNome();
			}
		}
		
		socketWriter.println(JOGADA_EFECTUADA + nomeCliente + " " + nome + " " + coluna + " " + simbolo);
	}
	
	public void analisarMensagem(String mensagem)
	{
		String[] parameters = mensagem.split(" ");
    	switch(parameters[0] + " ")
    	{
    		case LISTA_CLIENTES:
    			
    			for(int i = 0; i < Integer.parseInt(parameters[1]); i++)
    			{
    				clienteUI.adicionarClienteALista(new RepresentacaoCliente(parameters[2 + (3*i)], 226, 11 + (50 * i), 208, 50));    				
    			}
    			
    			break;
    	}
	}
	
	public void setClienteUI(ClienteUI clienteUI)
	{
		this.clienteUI = clienteUI;
	}
}

class RepresentacaoCliente extends JPanel
{
	public RepresentacaoCliente(String nome, int x, int y, int width, int height)
	{
		super();
		setBounds(x, y, width, height);
		setLayout(null);
		setBackground(new Color((int)(Math.random() * 255), (int)(Math.random() * 255), (int)(Math.random() * 255)));
		setVisible(true);
	}
}