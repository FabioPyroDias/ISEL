import java.io.File;
import java.io.IOException;
import java.io.StringReader;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class Mensagem {

	static Schema schema;
	
	public static void LoadXSD()
	{
		String xsdFile = "ProtocoloXSD.xsd";
	    SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
	    try {
			schema = schemaFactory.newSchema(new Source[] {
			    new StreamSource(
			        new File(xsdFile))
			});
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    System.out.println("Load Complete");
	}
	
	public static boolean ValidateXMLMessage(String xmlMessage)
	{
		StringReader stringReader = new StringReader(xmlMessage);
	    try 
	    {
			schema.newValidator().validate(new StreamSource(stringReader));
		} 
	    catch (Exception e) 
	    {
	    	e.printStackTrace();
			return false;
		}

	    stringReader.close();
	    
	    return true;
	}
	
	private static Document getXMLDocument(String xmlMessage)
	{
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;
		
		try
		{
			builder = factory.newDocumentBuilder();
			return builder.parse(new InputSource(new StringReader(xmlMessage)));
		}
		catch(Exception e)
		{
			System.out.println("Mensagem XML m� formada");
		}
		
		return null;
	}
	
	public static String[] analiseMessage(String xmlMessage)
	{
		Document xmlDoc = getXMLDocument(xmlMessage);

		Element messageElement = (Element) xmlDoc.getFirstChild().getFirstChild();

		switch(messageElement.getTagName())
		{
			case "SignIn":	
				
				return getParametersSignIn(messageElement);
			
			case "Login":
				
				return getParametersLogin(messageElement);
				
			case "LoginAnswer":
				
				System.out.println("MENSAGEM -> AnaliseMessage, LoginAnswer");
				
				return getParametersLoginAnswer(messageElement);
				
			default:
				
				return null;
		}
	}
	
	public static String[] getParametersSignIn(Element signInElement)
	{
		String parameters[] = new String[3];
		
		parameters[0] = signInElement.getTagName();
		parameters[1] = signInElement.getAttribute("playerName");
		parameters[2] = signInElement.getAttribute("password");
		
		return parameters;
	}
	
	public static String[] getParametersLogin(Element loginElement)
	{
		String parameters[] = new String[3];
		
		parameters[0] = loginElement.getTagName();
		parameters[1] = loginElement.getAttribute("playerName");
		parameters[2] = loginElement.getAttribute("password");
		
		return parameters;
	}
	
	public static String[] getParametersLoginAnswer(Element loginAnswerElement)
	{
		String[] parameters;
		System.out.print("Mensagem -> getParametersLoginAnswer ");
		if(loginAnswerElement.getAttribute("validate").equals("false"))
		{
			parameters = new String[2];
			
			parameters[0] = loginAnswerElement.getTagName();
			parameters[1] = "false";
			
			System.out.println("Entrei no validate: false");
			
			return parameters;
		}
		else
		{
			int numberOfPlayers = loginAnswerElement.getChildNodes().getLength();
			int playerInfoOffset = 4;
			
			parameters = new String[3 + numberOfPlayers * playerInfoOffset];
			
			parameters[0] = loginAnswerElement.getTagName();
			parameters[1] = "true";
			parameters[2] = Integer.toString(numberOfPlayers);
			
			for(int playerIndex = 0; playerIndex < numberOfPlayers; playerIndex++)
	    	{
				Element player = ((Element) loginAnswerElement.getChildNodes().item(playerIndex));
				
				parameters[playerIndex * playerInfoOffset] = player.getAttribute("playerName");
				parameters[playerIndex * playerInfoOffset + 1] = player.getAttribute("jogosJogados");
				parameters[playerIndex * playerInfoOffset + 2] = player.getAttribute("jogosGanhos");
				parameters[playerIndex * playerInfoOffset + 3] = player.getAttribute("jogosPerdidos");
	    	}
			
			System.out.println("Entrei no validate: true. Tamanho dos parametros: " + parameters.length);
			
			return parameters;	
		}
	
	}
	
	//TODO M�todos Cliente -> Servidor
	public static String SignIn(String playerName, String password)
	{
		return "<?xml version='1.0' encoding='ISO-8859-1' standalone='yes'?><Protocolo><SignIn playerName=\"" + playerName + "\" password=\""+ password + "\"/></Protocolo>";
	}
	
	public static String Login(String playerName, String password)
	{
		return "<?xml version='1.0' encoding='ISO-8859-1' standalone='yes'?><Protocolo><Login playerName=\"" + playerName + "\" password=\""+ password + "\"/></Protocolo>";
	}
	
	public static String PlayColumn(String player, String opponent, String column)
	{
		return "<?xml version='1.0' encoding='ISO-8859-1' standalone='yes'?><Protocolo><Login playerName=" + player + " opponent="+ opponent + " column=" + column + "/></Protocolo>";
	}
	
	//TODO M�todos Servidor -> Cliente
	public static String LoginAnswer(boolean validate, int numberOfPlayers, String[] playersInformation)
	{
		String message = "<?xml version='1.0' encoding='ISO-8859-1' standalone='yes'?><Protocolo><LoginAnswer validate=\"" + validate + "\"";
		
		if(!validate)
		{
			System.out.println("Mensagem -> Entrei no FALSE do LoginAnswer");
			return  message + "/></Protocolo>";
		}
		
		message += ">";
		
		int informationOffset = 4;
		
		for(int index = 0; index < numberOfPlayers; index++)
		{
			message += "<Player playerName=\"" + playersInformation[index * informationOffset] + "\" jogosJogados=\"" + playersInformation[index * informationOffset + 1] + "\" jogosGanhos=\"" + playersInformation[index * informationOffset + 2] + "\" jogosPerdidos=\"" + playersInformation[index * informationOffset + 3] + "\"/>";
		}
		System.out.println("MENSAGEM -> LoginAnswer, mensagem retornada: " + message);
		return message + "</LoginAnswer></Protocolo>";
	}
	
	public String AddPlayer(String playerName)
	{
		return "<?xml version='1.0' encoding='ISO-8859-1' standalone='yes'?><Protocolo><AddPlayer playerName=" + playerName + "></Protocolo>";
	}
	
	public String RemovePlayer(String playerName)
	{
		return "<?xml version='1.0' encoding='ISO-8859-1' standalone='yes'?><Protocolo><RemovePlayer playerName=" + playerName + "></Protocolo>";
	}
/*	
	String xsdFile = "//somewhere/myxsd.xsd";
    SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
    Schema schema = schemaFactory.newSchema(new Source[] {
        new StreamSource(
            new File(xsdFile))
    });
 
    StringReader stringReader = new StringReader(xmlString);
    schema.newValidator().validate(
        new StreamSource(stringReader)
    );
  */
}