import java.util.Scanner;

public class Jogo {

	private final int COLS_NUM = 8;
	private final int ROWS_NUM = 8;
	String[][] board;

	private boolean isGameRunning;
	private boolean isPlayer1Turn;
	
	public Jogo()
	{
		initializeBoard();
		
		isGameRunning = true;
		isPlayer1Turn = true;
	}
	
	private void initializeBoard()
	{
		board = new String[ROWS_NUM][COLS_NUM];
		
		for(int row = 0; row < ROWS_NUM; row++)
		{
			for(int col = 0; col < COLS_NUM; col++)
			{
				board[row][col] = "";
			}	
		}
	}

	public void makePlay(String player, int column)
	{
		
	}
}