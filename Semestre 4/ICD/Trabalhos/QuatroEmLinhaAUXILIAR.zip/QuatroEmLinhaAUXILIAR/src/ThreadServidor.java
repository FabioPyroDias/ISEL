import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

class ThreadServidor extends Thread {

	private RegistoCliente eu;
	private Dados dados;

	private Socket connection;
    private BufferedReader socketReader;
    private PrintWriter socketWriter;

    public ThreadServidor(Socket connection, Dados dados) {
        this.connection = connection;
        this.dados = dados;
    }

    public void run() {

        try {
            socketReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            socketWriter = new PrintWriter(connection.getOutputStream(), true);
            
            for(;;)
            {
            	String inputLine = socketReader.readLine();
            	AnaliseMessage(inputLine);           	
            }
            
        }
        catch (IOException e) {
            System.err.println("erro na liga�ao " + connection + ": " + e.getMessage());
        }
        finally {
            // garantir que o socket � fechado
            try {
                if (socketReader != null) socketReader.close();  
                if (socketWriter != null) socketWriter.close();

                if (connection != null) connection.close();                    
            } catch (IOException e) { } 
        }
        
    } // end run
    
    private void AnaliseMessage(String message)
    {
    	System.out.println("Recebi Mensagem!");
    	System.out.println(message);
    	
    	if(!Mensagem.ValidateXMLMessage(message))
    	{
    		System.out.println("Mensagem Inv�lida");
    		return;
    		//TODO Se o XSD n�o validar o XML recebido, posso fechar a coneccao. Mas como?
    	}
    	
    	String[] parameters = Mensagem.analiseMessage(message);
    	
    	switch(parameters[0])
    	{
    		case "SignIn":
    			if(dados.verifyPlayer(parameters[1]) == null)
    			{
    				registarCliente(parameters[1], parameters[2], true);
    			}
    			else
    			{
    				//Enviar mensagem a informar que o jogador j� existe.
    				System.out.println("O jogador j� existe");
    			}
    			
    			break;
    			
    		case "Login":
    			if(dados.verifyPlayer(parameters[1]) == null)
    			{
    				//Enviar mensagem a informar que o jogador n�o existe.
    				System.out.println("O jogador n�o existe");
    			}
    			else
    			{
    				if(dados.verifyPassword(parameters[1], parameters[2]))
    				{
    					System.out.println("Password Correcta");
    					registarCliente(parameters[1], parameters[2], false);
    					enviarListaClientes(true);
    				}
    				else
    				{
    					System.out.println("Password Errada");
    					socketWriter.println("NO NO NO");
    					//Enviar mensagem a informar que a password est� errada.
    				}
    			}
    			
    			break;
    	}
    }
    
    private void registarCliente(String playerName, String password, boolean addPlayerInDatabase)
    {
    	eu = new RegistoCliente();
        eu.setNome(playerName);
        eu.setSocket(connection);
        eu.setSocketReader(socketReader);
        eu.setSocketWriter(socketWriter);
        
        dados.listaClientes.add(eu);
    
        if(addPlayerInDatabase)
        {
        	dados.registerPlayer(playerName, password);        	
        }
        else
        {
        	String[] info = dados.loadPlayer(playerName);
        	
        	eu.setJogosPerdidos(Integer.parseInt(info[0]));
        	eu.setJogosJogados(Integer.parseInt(info[1]));
        	eu.setJogosGanhos(Integer.parseInt(info[2]));
        	eu.setNacionalidade(info[3]);
        	eu.setIdade(Integer.parseInt(info[4]));
        	eu.setFotografia(info[5]);
        }
    }
    
    private void enviarListaClientes(boolean validate)
    {
    	if(!validate)
    	{
    		eu.getSocketWriter().println(Mensagem.LoginAnswer(false, 0, null));
    		return;
    	}
    	
    	int clientsLength = dados.listaClientes.size();
    	int clientInfoOffset = 4;
    	String[] playersInfo = new String[clientsLength * clientInfoOffset];
    	
    	for(int clientIndex = 0; clientIndex < clientsLength; clientIndex++)
    	{
    		RegistoCliente client = dados.listaClientes.get(clientIndex);
    		
    		playersInfo[clientIndex * clientInfoOffset] = client.getNome();
    		playersInfo[clientIndex * clientInfoOffset + 1] = Integer.toString(client.getJogosJogados());
    		playersInfo[clientIndex * clientInfoOffset + 2] = Integer.toString(client.getJogosGanhos());
    		playersInfo[clientIndex * clientInfoOffset + 3] = Integer.toString(client.getJogosPerdidos());
    	}
    	
    	eu.getSocketWriter().println(Mensagem.LoginAnswer(true, clientsLength, playersInfo));
    }

    private void executarJogada(String coluna, String simbolo)
    {
    	//Inserir pe�a no Tabuleiro.
    	
    }
    
    private void actualizarTurno(String jogadorQueEfectuouJogada)
    {
    	
    }
    
    /*//TODO NOTAS:
     * -> Atualiza��o da Lista de Clientes
     * Sempre que um jogador se registar, a ThreadServidor vai ter de atualizar a 
     * representa��o visual da lista de clientes dos outros Clientes, o lobby.
     * Para tal, vai ter de existir um m�todo que volta a enviar a lista atualizada
     * de clientes e, na ThreadCliente, quando receber essa mensagem, informa a classe
     * base Cliente que, por sua vez, pega nessa mensagem e atualiza a representa��o
     * visual com base nessa mensagem.
     * Assim, acredito que a classe ClienteUI tamb�m vai ter de ser passada como
     * parametro para a classe Cliente.
     * 
     *
     */
}