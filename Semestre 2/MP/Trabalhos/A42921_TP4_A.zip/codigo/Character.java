package tp4;

public abstract class Character {
	protected String nome;
	protected int healthPoints;
	protected int attackPoints;
	protected int defensePoints;
	
	public Character(String nome, int healthPoints, int attackPoints, int defensePoints)
	{
		this.nome = nome;
		this.healthPoints = healthPoints;
		this.attackPoints = attackPoints;
		this.defensePoints = defensePoints;
	}
	
	public String getNome()
	{
		return nome;
	}
	
	public int getHealthPoints()
	{
		return healthPoints;
	}
	
	public int getAttackPoints()
	{
		return attackPoints;
	}
	
	public int getDefensePoints()
	{
		return defensePoints;
	}
}
